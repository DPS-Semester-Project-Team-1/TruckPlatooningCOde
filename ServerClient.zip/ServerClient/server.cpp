#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <json/json.h>  // JSON library for structured data (optional)

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};

    // Example structured data using JSON (optional)
    Json::Value msgData;
    msgData["carDetected"] = true;
    msgData["speed"] = 50;
    msgData["distance"] = 100;
    Json::StreamWriterBuilder writer;
    std::string msgCar = Json::writeString(writer, msgData);

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        std::cerr << "Socket creation failed!" << std::endl;
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8080);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address or Address not supported" << std::endl;
        return -1;
    }

    // Connect to server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed" << std::endl;
        return -1;
    }

    // Send structured message
    send(sock, msgCar.c_str(), msgCar.length(), 0);
    std::cout << "Message sent to server: " << msgCar << std::endl;

    // Read server response
    int bytesRead = read(sock, buffer, 1024);
    if (bytesRead < 0) {
        std::cerr << "Failed to read from server!" << std::endl;
        close(sock);
        return -1;
    }

    buffer[bytesRead] = '\0';
    std::cout << "Message from server: " << buffer << std::endl;

    close(sock);
    return 0;
}
