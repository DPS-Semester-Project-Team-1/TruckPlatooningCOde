#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};
    const char *msgCar = "Car Detected";  // Message to send to server

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        std::cerr << "Socket creation failed!" << std::endl;
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8080);  // Port same as the server

    // Convert IPv4 address from text to binary form
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address or Address not supported" << std::endl;
        return -1;
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed" << std::endl;
        return -1;
    }

    // Send message to server
    send(sock, msgCar, strlen(msgCar), 0);
    std::cout << "Message sent to server: " << msgCar << std::endl;

    // Read the processed data (response from server)
    int bytesRead = read(sock, buffer, 1024);
    if (bytesRead < 0) {
        std::cerr << "Failed to read from server!" << std::endl;
        close(sock);
        return -1;
    }

    // Null-terminate the received data and print it
    buffer[bytesRead] = '\0';  // Ensure the message is null-terminated
    std::cout << "Message from server: " << buffer << std::endl;

    // Close the socket
    close(sock);
    return 0;
}
